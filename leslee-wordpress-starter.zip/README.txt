
# Leslee Kadence Child Theme (Starter)
1) Install Kadence theme
2) Upload `leslee-kadence-child` as a theme (Appearance → Themes → Add New → Upload Theme)
3) Activate the child theme
4) Create a Home page and paste the Gutenberg "Home Pattern" from `/import/home-gutenberg.html` into the editor (Code Editor view)
5) Set the Home page in Settings → Reading
6) Install plugins: WPForms Lite, Rank Math, Autoptimize, caching, Site Kit, Redirection, Complianz, Limit Login Attempts
7) Replace images and update Contact details/areaServed in functions.php schema block
