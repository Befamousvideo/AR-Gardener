
<?php
/**
 * Theme functions for Leslee Kadence Child
 */

add_action('wp_enqueue_scripts', function(){
  wp_enqueue_style('leslee-child', get_stylesheet_uri(), [], '1.0.0');
  // Inter font (fallback if theme doesn't already load it)
  wp_enqueue_style('leslee-inter-font', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap', [], null);
});

// Add JSON-LD to <head> (edit address/areaServed as needed)
add_action('wp_head', function(){
  $schema = [
    "@context" => "https://schema.org",
    "@type" => "LocalBusiness",
    "name" => "Leslee Cook, MFT, SEP, NARM",
    "url" => home_url('/'),
    "telephone" => "+1-310-617-2577",
    "image" => get_template_directory_uri() . "/screenshot.png",
    "address" => [
      "@type" => "PostalAddress",
      "addressLocality" => "",
      "addressRegion" => "CA",
      "addressCountry" => "US"
    ],
    "areaServed" => "California",
    "description" => "Somatic Experiencing® and NARM therapy for anxiety, PTSD, chronic pain, and stress."
  ];
  echo '<script type="application/ld+json">'.wp_json_encode($schema).'</script>';
});
